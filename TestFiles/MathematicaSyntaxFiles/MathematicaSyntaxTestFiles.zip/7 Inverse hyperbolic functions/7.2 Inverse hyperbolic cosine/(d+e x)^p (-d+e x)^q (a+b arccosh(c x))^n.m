(* ::Package:: *)

{(-1 + c*x)^(5/2)*Sqrt[1 + c*x]*(a + b*ArcCosh[c*x]), x, 0, 0}
{(-1 + c*x)^(3/2)*Sqrt[1 + c*x]*(a + b*ArcCosh[c*x]), x, 0, 0}
{(-1 + c*x)^(1/2)*Sqrt[1 + c*x]*(a + b*ArcCosh[c*x]), x, 3, (-(1/4))*b*c*x^2 + (1/2)*x*Sqrt[-1 + c*x]*Sqrt[1 + c*x]*(a + b*ArcCosh[c*x]) - (a + b*ArcCosh[c*x])^2/(4*b*c)}
{Sqrt[1 + c*x]*(a + b*ArcCosh[c*x])/(-1 + c*x)^(1/2), x, 0, 0}
{Sqrt[1 + c*x]*(a + b*ArcCosh[c*x])/(-1 + c*x)^(3/2), x, 0, 0}
{Sqrt[1 + c*x]*(a + b*ArcCosh[c*x])/(-1 + c*x)^(5/2), x, 7, (b*Sqrt[(1 - c*x)*(1 + c*x)]*Sqrt[1 - c^2*x^2])/(3*c*Sqrt[-1 + c*x]*(-((1 - c*x)/(1 + c*x)))^(3/2)*(1 + c*x)^(3/2)) - ((1 + c*x)^(3/2)*(a + b*ArcCosh[c*x]))/(3*c*(-1 + c*x)^(3/2)) - (2*b*Sqrt[(1 - c*x)*(1 + c*x)]*Sqrt[1 - c^2*x^2]*Log[Sqrt[-((1 - c*x)/(1 + c*x))]])/(3*c*Sqrt[-1 + c*x]*Sqrt[-((1 - c*x)/(1 + c*x))]*(1 + c*x)^(3/2)) + (b*Sqrt[(1 - c*x)*(1 + c*x)]*Sqrt[1 - c^2*x^2]*Log[2/(1 + c*x)])/(3*c*Sqrt[-1 + c*x]*Sqrt[-((1 - c*x)/(1 + c*x))]*(1 + c*x)^(3/2))}


{(-1 + c*x)^(5/2)*(1 + c*x)^(3/2)*(a + b*ArcCosh[c*x]), x, 0, 0}
{(-1 + c*x)^(3/2)*(1 + c*x)^(3/2)*(a + b*ArcCosh[c*x]), x, 6, (5/16)*b*c*x^2 - (1/16)*b*c^3*x^4 - (3/8)*x*Sqrt[-1 + c*x]*Sqrt[1 + c*x]*(a + b*ArcCosh[c*x]) + (1/4)*x*(-1 + c*x)^(3/2)*(1 + c*x)^(3/2)*(a + b*ArcCosh[c*x]) + (3*(a + b*ArcCosh[c*x])^2)/(16*b*c)}
{(-1 + c*x)^(1/2)*(1 + c*x)^(3/2)*(a + b*ArcCosh[c*x]), x, 0, 0}
{(1 + c*x)^(3/2)*(a + b*ArcCosh[c*x])/(-1 + c*x)^(1/2), x, 0, 0}
{(1 + c*x)^(3/2)*(a + b*ArcCosh[c*x])/(-1 + c*x)^(3/2), x, 0, 0}
{(1 + c*x)^(3/2)*(a + b*ArcCosh[c*x])/(-1 + c*x)^(5/2), x, 0, 0}


{(-1 + c*x)^(5/2)/Sqrt[1 + c*x]*(a + b*ArcCosh[c*x]), x, 0, 0}
{(-1 + c*x)^(3/2)/Sqrt[1 + c*x]*(a + b*ArcCosh[c*x]), x, 0, 0}
{(-1 + c*x)^(1/2)/Sqrt[1 + c*x]*(a + b*ArcCosh[c*x]), x, 0, (-b)*x + (b*ArcCosh[c*x]^2)/(2*c) + (Sqrt[-1 + c*x]*Sqrt[1 + c*x]*(a + b*ArcCosh[c*x]))/c - (ArcCosh[c*x]*(a + b*ArcCosh[c*x]))/c}
{(a + b*ArcCosh[c*x])/((-1 + c*x)^(1/2)*Sqrt[1 + c*x]), x, 1, (a + b*ArcCosh[c*x])^2/(2*b*c)}
{(a + b*ArcCosh[c*x])/((-1 + c*x)^(3/2)*Sqrt[1 + c*x]), x, 8, -((Sqrt[1 + c*x]*(a + b*ArcCosh[c*x]))/(c*Sqrt[-1 + c*x])) - (2*b*Sqrt[(1 - c*x)*(1 + c*x)]*Sqrt[1 - c^2*x^2]*Log[Sqrt[-((1 - c*x)/(1 + c*x))]])/(c*Sqrt[-1 + c*x]*Sqrt[-((1 - c*x)/(1 + c*x))]*(1 + c*x)^(3/2)) + (b*Sqrt[(1 - c*x)*(1 + c*x)]*Sqrt[1 - c^2*x^2]*Log[2/(1 + c*x)])/(c*Sqrt[-1 + c*x]*Sqrt[-((1 - c*x)/(1 + c*x))]*(1 + c*x)^(3/2))}
{(a + b*ArcCosh[c*x])/((-1 + c*x)^(5/2)*Sqrt[1 + c*x]), x, 11, -(b/(3*c*(1 - c*x))) + (2*b*Sqrt[1 - c^2*x^2])/(3*c*(1 - c*x)^(3/2)*Sqrt[1 + c*x]) - (Sqrt[1 + c*x]*(a + b*ArcCosh[c*x]))/(3*c*(-1 + c*x)^(3/2)) + (Sqrt[1 + c*x]*(a + b*ArcCosh[c*x]))/(3*c*Sqrt[-1 + c*x]) - (2*b*Log[Sqrt[-1 + c*x]])/(3*c)}


{(-1 + c*x)^(5/2)/(1 + c*x)^(3/2)*(a + b*ArcCosh[c*x]), x, 0, 0}
{(-1 + c*x)^(3/2)/(1 + c*x)^(3/2)*(a + b*ArcCosh[c*x]), x, 0, 0}
{(-1 + c*x)^(1/2)/(1 + c*x)^(3/2)*(a + b*ArcCosh[c*x]), x, 0, 0}
{(a + b*ArcCosh[c*x])/((-1 + c*x)^(1/2)*(1 + c*x)^(3/2)), x, 5, (Sqrt[-1 + c*x]*(a + b*ArcCosh[c*x]))/(c*Sqrt[1 + c*x]) - (b*Sqrt[(1 - c*x)*(1 + c*x)]*Sqrt[1 - c^2*x^2]*Log[2/(1 + c*x)])/(c*Sqrt[-1 + c*x]*Sqrt[-((1 - c*x)/(1 + c*x))]*(1 + c*x)^(3/2))}
{(a + b*ArcCosh[c*x])/((-1 + c*x)^(3/2)*(1 + c*x)^(3/2)), x, 2, -((x*(a + b*ArcCosh[c*x]))/(Sqrt[-1 + c*x]*Sqrt[1 + c*x])) + (b*Log[1 - c^2*x^2])/(2*c)}
{(a + b*ArcCosh[c*x])/((-1 + c*x)^(5/2)*(1 + c*x)^(3/2)), x, 19, (b*Sqrt[1 - c^2*x^2])/(6*c*(1 - c*x)^(3/2)*Sqrt[1 + c*x]) - (a + b*ArcCosh[c*x])/(3*c*(-1 + c*x)^(3/2)*Sqrt[1 + c*x]) + (2*x*(a + b*ArcCosh[c*x]))/(3*Sqrt[-1 + c*x]*Sqrt[1 + c*x]) + (b*Sqrt[1 - c^2*x^2]*ArcTanh[c*x])/(6*c*Sqrt[1 - c*x]*Sqrt[1 + c*x]) - (2*b*Log[Sqrt[-1 + c*x]])/(3*c) - (b*Log[1 + c*x])/(3*c)}
