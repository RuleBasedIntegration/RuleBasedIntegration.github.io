(* ::Package:: *)

Paclet[
  Name -> "IntegrationTestProgram",
  Version -> "2018.12.22",
  MathematicaVersion -> "9+",
  Description -> "Integration Test Program",
  Creator -> "Albert D. Rich",
  URL -> "https://rulebasedintegration.org",
  Extensions ->
      {
        {"Kernel", Root -> ".", Context -> "IntegrationTestProgram`"},
        {"PacletServer",
          "Tags" -> {"integration", "integration test program"},
          "Categories" -> {"Mathematics"},
          "Description" -> "IntegrationTestProgram is a package for testing Rubi and Mathematica's built-in integrator on a large test-suite of integration problems.",
          "License" -> "MIT"
        }
      }
]
